# COL362/COL632 Assignment_3

In memory database system for quering CSV files. 

